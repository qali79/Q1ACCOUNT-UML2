import java.util.Random;

public class RainfallAnalysis {

    public static void main(String[] args) {

        int[] rainfall = new int[30];

        Random rand = new Random();

        int total = 0;
        int wetDays = 0;

        // Generate rainfall data
        for (int i = 0; i < 30; i++) {

            rainfall[i] = rand.nextInt(61); // 0–60 mm
            total += rainfall[i];

            if (rainfall[i] > 30) {
                wetDays++;
            }
        }

        double average = total / 30.0;

        // Output results
        System.out.println("=== RAINFALL REPORT ===");
        System.out.println("Total Rainfall: " + total);
        System.out.println("Average Rainfall: " + average);
        System.out.println("Wet Days (>30mm): " + wetDays);

        // Classification
        if (total <= 300) {
            System.out.println("Month Classification: Dry");
        }
        else if (total <= 600) {
            System.out.println("Month Classification: Normal");
        }
        else {
            System.out.println("Month Classification: Flood-risk");
        }
    }
}