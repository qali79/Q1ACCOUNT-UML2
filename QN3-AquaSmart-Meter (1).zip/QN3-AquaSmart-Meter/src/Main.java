public class Main {

    public static void main(String[] args) {

        SmartMeter meter =
                new SmartMeter("MTR001", 5000);

        System.out.println("Initial Credit: "
                + meter.getCreditBalance());

        meter.recordConsumption(20);

        System.out.println("Balance: "
                + meter.getCreditBalance());

        meter.recordConsumption(100);

        System.out.println("Valve Open: "
                + meter.isValveOpen());

        meter.loadToken(3000);

        System.out.println("Balance after token: "
                + meter.getCreditBalance());

        System.out.println("Valve Open: "
                + meter.isValveOpen());

    }

}