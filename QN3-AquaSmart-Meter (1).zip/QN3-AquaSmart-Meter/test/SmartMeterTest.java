import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class SmartMeterTest {

    @Test
    public void testLoadTokenReopensValve() {

        SmartMeter meter =
                new SmartMeter("001",100);

        meter.recordConsumption(5);

        meter.loadToken(1000);

        assertTrue(meter.isValveOpen());

    }

    @Test
    public void testConsumptionClosesValve() {

        SmartMeter meter =
                new SmartMeter("002",200);

        meter.recordConsumption(10);

        assertFalse(meter.isValveOpen());

    }

}